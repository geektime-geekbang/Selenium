selenium-ide-for-chrome
=======================

Unofficial project.

Usage
=======================

Download ChromeDriver https://code.google.com/p/chromedriver/downloads/list

Execute chromedriver

Download zip https://github.com/kyo-ago/selenium-ide-for-chrome/archive/master.zip

Unzip download file

Open chrome://extensions/

Enable "Developer mode" checkbox

Click "Load unpacketd extension..."

Select unziped directory

License
=======================
Apache 2.0 License.

=======================

[http://code.google.com/p/selenium/](selenium - Browser automation framework - Google Project Hosting)

[http://code.google.com/p/selenium/wiki/JsonWireProtocol](JsonWireProtocol - selenium - A description of the protocol used by WebDriver to communicate with remote instances - Browser automation framework - Google Project Hosting)

[http://code.google.com/p/selenium/wiki/ChromeDriver](ChromeDriver - selenium - Information about the Chrome Driver - Browser automation framework - Google Project Hosting)

[CapabilitiesAndSwitches - chromedriver - List of supported capabilities and command-line arguments - WebDriver for Google Chrome - Google Project Hosting](https://code.google.com/p/chromedriver/wiki/CapabilitiesAndSwitches)

[List of Chromium Command Line Switches « Peter Beverloo](http://peter.sh/experiments/chromium-command-line-switches/)

https://gist.github.com/3853421

https://github.com/kyo-ago/selenium-ide-for-chrome/blob/860b2d4bf93cefacfb2b9983e1a0668ffe1f8459/src/panel/index.js

https://code.google.com/p/selenium/source/browse/COPYING

	https://selenium.googlecode.com/git/ide/main/src/skin/classic/icons.png
