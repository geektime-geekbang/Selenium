java -jar selenium-server-standalone-3.141.59.jar -role hub -hubConfig hub_config.json 

java -jar selenium-server-standalone-3.141.59.jar -role node -nodeConfig node_config.json
